


function crearArray(){

    let numeros = []

    for(let i = 0; i < 20; ++i){

       numeros.push(Math.floor((Math.random() * 20) + i) )
       console.log(numeros[i])
    }
    for(let value of numeros){

       console.log(value)
    }
}

function arrayPop(){

    let numeros2 = []

    for(let i = 0; i < 20; ++i){

        numeros2.push(Math.floor((Math.random() * 20) + i) )
        console.log(numeros2[i])
    }

    numeros2.pop()

    for(let value of numeros2){

        console.log(value)
     }
}

function splice2(){

    let numeros3 = []
    let posición = 2

    for(let i = 0; i < 5; ++i){

        numeros3.push(Math.floor(Math.random() * 20))
        console.log(numeros3[i])
    }

    numeros3.splice(posición, 1)

    for(let value of numeros3){

        console.log(value)
     }

}

function myFunction(... matriz){
    
    for(elemento of matriz){
        
        console.log(elemento)
    }
}

crearArray()
arrayPop()
splice2()
myFunction(1,2,3,4,5,"hola")
