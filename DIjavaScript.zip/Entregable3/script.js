function recomendar(genero){

    let edad = parseInt(document.getElementById("edad").value);
    let recomendacion = "";

    if(edad <= 0){
        recomendacion = "Edad introducida no válida";
    }else{
        switch(genero){
            case "comedia":
                if(edad >= 16){
                    recomendacion = "The Wolf of Wall Street";
                }
                if(edad >= 13){
                    recomendacion = "The Truman Show";
                }else{
                    recomendacion = "Back to the Future";
                }

                break;

            case "crimen":
                if(edad >= 16){
                    recomendacion = "The Godfather";
                }
                if(edad >= 13){
                    recomendacion = "El secreto de sus ojos";
                }else{
                    recomendacion = "No hay películas disponibles para tu edad."
                }

                break;
            
            case "drama":
                if(edad >= 16){
                    recomendacion = "Taxi Driver";
                }
                if (edad >= 13) {
                    recomendacion = "The Shawshank Redemption";
                }else {
                    recomendacion = "Casablanca";
                }

                break;
            
            case "musical":
                if(edad >= 16){
                    recomendacion = "The Rocky Horror Picture Show";
                }
                if (edad >= 13) {
                    recomendacion = "Les Miserables";
                }else {
                    recomendacion = "La La Land";
                }
                break;
            
            default:
                recomendacion = "Género no válido.";
        }

        recomendacion = document.getElementById("recomendacion").value;
    }

}