const calificaciones = [5, 8, 3, 6, 9];

        // Función 1: Mostrar lista de calificaciones
        function mostrarCalificaciones() {
            const resultado = document.getElementById('resultado');
            resultado.innerHTML = '<h2>Lista de Calificaciones:</h2>';
            const ul = document.createElement('ul');

            for (const calificacion of calificaciones) {
                const li = document.createElement('li');
                li.textContent = `Calificación: ${calificacion}`;
                ul.appendChild(li);
            }
            resultado.appendChild(ul);
        }

        // Función 2: Calcular promedio general
        function calcularPromedio() {
            let suma = 0;
            for (let i = 0; i < calificaciones.length; i++) {
                suma += calificaciones[i];
            }
            const promedio = suma / calificaciones.length;
            document.getElementById('resultado').innerHTML = `<h2>Promedio General: ${promedio.toFixed(2)}</h2>`;
        }

        // Función 3: Obtener la calificación más alta
        function obtenerNotaMasAlta() {
            let notaMasAlta = 0;
            let i = 0;
            while (i < calificaciones.length) {
                if (calificaciones[i] > notaMasAlta) {
                    notaMasAlta = calificaciones[i];
                }
                i++;
            }
            document.getElementById('resultado').innerHTML = `<h2>Calificación Más Alta: ${notaMasAlta}</h2>`;
        }

        // Función 4: Verificar si hay algún aplazo
        function verificarAplazo() {
            let hayAplazo = false;
            let i = 0;
            do {
                if (calificaciones[i] < 4) {
                    hayAplazo = true;
                    break;
                }
                i++;
            } while (i < calificaciones.length);

            if (hayAplazo) {
                document.getElementById('resultado').innerHTML = '<h2>¡Hay un aplazo!</h2>';
            } else {
                document.getElementById('resultado').innerHTML = '<h2>No hay aplazos.</h2>';
            }
        }