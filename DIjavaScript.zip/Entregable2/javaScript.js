function mostrarResultado(valor) {
    document.getElementById("resultado").value = valor;
  }
  
  // Operaciones básicas
  function sumar() {
    const num1 = parseFloat(document.getElementById("num1").value);
    const num2 = parseFloat(document.getElementById("num2").value);
    mostrarResultado(num1 + num2);
  }
  
  function restar() {
    const num1 = parseFloat(document.getElementById("num1").value);
    const num2 = parseFloat(document.getElementById("num2").value);
    mostrarResultado(num1 - num2);
  }
  
  function multiplicar() {
    const num1 = parseFloat(document.getElementById("num1").value);
    const num2 = parseFloat(document.getElementById("num2").value);
    mostrarResultado(num1 * num2);
  }
  
  function dividir() {
    const num1 = parseFloat(document.getElementById("num1").value);
    const num2 = parseFloat(document.getElementById("num2").value);
    mostrarResultado(num2 !== 0 ? num1 / num2 : "Error: Div/0");
  }
  
  // Operación potencia
  function potencia() {
    const num1 = parseFloat(document.getElementById("num1").value);
    const num2 = parseFloat(document.getElementById("num2").value);
    mostrarResultado(Math.pow(num1, num2));
  }
  
  // Raíz cuadrada y valor absoluto
  function raizCuadrada() {
    const num2 = parseFloat(document.getElementById("num2").value);
    mostrarResultado(num2 >= 0 ? Math.sqrt(num2) : "Error: raíz negativa");
  }
  
  function valorAbsoluto() {
    const num2 = parseFloat(document.getElementById("num2").value);
    mostrarResultado(Math.abs(num2));
  }
  
  // Número aleatorio
  function generarAleatorio() {
    const num1 = parseFloat(document.getElementById("num1").value);
    const num2 = parseFloat(document.getElementById("num2").value);
    if (num1 < num2) {
      mostrarResultado(Math.random() * (num2 - num1) + num1);
    } else {
      mostrarResultado("Error: min > max");
    }
  }
  
  // Redondeos
  function redondear() {
    const resultado = parseFloat(document.getElementById("resultado").value);
    mostrarResultado(Math.round(resultado));
  }
  
  function redondearAbajo() {
    const resultado = parseFloat(document.getElementById("resultado").value);
    mostrarResultado(Math.floor(resultado));
  }
  
  function redondearArriba() {
    const resultado = parseFloat(document.getElementById("resultado").value);
    mostrarResultado(Math.ceil(resultado));
  }